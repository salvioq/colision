package com.dam.colision;

public enum Contenido {
    CABEZA, CUERPO;
}
