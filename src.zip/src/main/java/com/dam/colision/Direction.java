package com.dam.colision;

public enum Direction {
    NORTE, SUR, ESTE, OESTE
}
